
CREATE TABLE IF NOT EXISTS `student_record` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `firstname` varchar(50) NOT NULL,
 `lastname` varchar(50) NOT NULL,
 `birthdate` datetime NOT NULL,
 `number`int(11) NOT NULL,
 `coursename` varchar(50),
 `coursedetails` varchar(50)
 PRIMARY KEY (`id`)
 );
 
 
 CREATE TABLE IF NOT EXISTS `course_record` (
 `coursename` varchar(50) NOT NULL,
 `coursedetails` varchar(50) NOT NULL,
 `id` int(10),
 PRIMARY KEY (`coursename`),
 FOREIGN KEY (`id`) REFERENCES `student_record`(`id`)
 );