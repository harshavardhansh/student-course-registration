<?php
require('db.php');
$id=$_REQUEST['id'];
$query = "SELECT * from student_record where id='".$id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Student Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="student.php">Student Record</a> 
| <a href="coursedetails.php">Course details</a></p>
| <a href="courseview.php">Course view</a></p>
<h1>Update Student Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];

$firstname =$_REQUEST['firstname'];
$lastname =$_REQUEST['lastname'];

$update="update student_record set 
firstname='".$firstname."', lastname='".$lastname."',
where id='".$id."'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "Record Updated Successfully. </br></br>
<a href='view.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="text" name="name" placeholder="Enter First Name" 
required value="<?php echo $row['firstname'];?>" /></p>
<p><input type="text" name="name" placeholder="Enter Last Name" 
required value="<?php echo $row['lastname'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
</div>
</body>
</html>