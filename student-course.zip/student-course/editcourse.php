<?php
require('db.php');
$id=$_REQUEST['id'];
$query = "SELECT * from student_record where id='".$id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Course Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="student.php">Student Record</a> 
| <a href="coursedetails.php">Course details</a></p>
| <a href="courseview.php">Course view</a></p>
<h1>Update Course Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];

$coursename =$_REQUEST['coursename'];
$coursedetails =$_REQUEST['coursedetails'];

$update="update course_record set 
coursename='".$coursename."', coursedetails='".$coursedetails."',
where id='".$id."'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "Record Updated Successfully. </br></br>
<a href='view.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="text" name="name" placeholder="Enter course Name" 
required value="<?php echo $row['coursename'];?>" /></p>
<p><input type="text" name="name" placeholder="Enter course details" 
required value="<?php echo $row['coursedetails'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
</div>
</body>
</html>