<?php
    include "MyClass.php";
?>
 
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<h2>Student course registration</h2>
    <?php 
 
        $obj = new MyClass();
        $rowone = $obj->getData("select id from student_record"); 
		$rowtwo = $obj->getData("select coursename from course_record");
		$rowthree = $obj->updateData("update student_record" set coursename='$coursename',coursedetails='$coursedetails' where id='$id')
    ?>
    <select>
        <?php foreach($row as $rowone){ ?>
            <option value='<?php echo $rowtwo['coursename'] ?>'></option>
               
    <?php  } ?>
    </select>
</body>
</html>