Student course registration- a simple student-course registration application which can be used to enter/update students enrolled and course registerd.

createtable.sql to be used to create required tables for student and course registration.

dashboard.php can be used as a starting page.