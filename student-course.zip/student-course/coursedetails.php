<?php
require('db.php');
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    
    $coursename =$_REQUEST['coursename'];
	$coursedetails =$_REQUEST['coursedetails'];
    $ins_query="insert into course_record
    (`coursename`,`coursedetails`)values
    ('$coursename','$coursedetails')";
    mysqli_query($con,$ins_query)
    or die(mysql_error());
    $status = "New Record Inserted Successfully.
    </br></br><a href='courseview.php'>View Inserted Record</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="studentview.php">View Student Records</a> 
<div>
<h1>Course Details</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><input type="text" name="coursename" placeholder="Enter Course Name" required />Course Name</p>
<p><input type="text" name="coursedetails" placeholder="Enter course Details" required />Course Details</p>

<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>