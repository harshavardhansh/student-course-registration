<?php
require('db.php');
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    
    $firstname =$_REQUEST['firstname'];
	$lastname =$_REQUEST['lastname'];
    $birthdate = $_REQUEST['birthdate'];
    $number = $_REQUEST['number'];
    $ins_query="insert into student_record
    (`firstname`,`lastname`,`birthdate`,`number`, ,)values
    ('$firstname','$lastname','$birthdate','$number', ,)";
    mysqli_query($con,$ins_query)
    or die(mysql_error());
    $status = "New Record Inserted Successfully.
    </br></br><a href='studentview.php'>View Inserted Record</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="studentview.php">View Student Records</a>
| <a href="coursedetails.php">Course details</a></p>
| <a href="courseview.php">Course view</a></p> 
<div>
<h1>Student Details</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><input type="text" name="firstname" placeholder="Enter First Name" required />First Name</p>
<p><input type="text" name="lastname" placeholder="Enter Last Name" required />Last Name</p>
<p><input type="date" name="birthdate" placeholder="DOB" required />DOB</p>
<p><input type="number" name="number" placeholder="Enter Contact Number" required />Contact Number</p>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>